let slides = document.querySelectorAll('.slide')
let prevbtn = document.querySelector('.prev')
let nxtbtn = document.querySelector('.next')


// The forEach() method calls a function for each element in an slide.// 
slides.forEach(function (slide, index) {
    slide.style.left = '$(index * 100)%';
} );

let counter = 0;

function nextbtn(){
    counter++;
    // console.log("hi")
}

function prevbtn() {
    counter--;
}


function carousel()
slides.forEach(function (slide) {
    slide.style.transform = 'translateX(-$(counter * 100)%';
} );